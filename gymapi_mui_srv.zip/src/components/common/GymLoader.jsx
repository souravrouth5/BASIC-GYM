

export function GymLoader(){

    return(
        <>
        
        </>
    )
}